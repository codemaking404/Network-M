from setuptools import setup, find_packages

setup(
    name="network_m",
    version="0.1.0",
    py_modules=["network-M"], # This tells pip to look for your specific filename
    install_requires=[
        "requests",
        "beautifulsoup4",
    ],
)