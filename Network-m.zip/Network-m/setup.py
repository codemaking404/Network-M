from setuptools import setup

setup(
    name="network-m-maddo", # This is the name people will use for 'pip install'
    version="0.1.0",
    py_modules=["network_m"], # Matches your filename 'network_m.py'
    install_requires=[
        "requests",
        "beautifulsoup4",
    ],
)