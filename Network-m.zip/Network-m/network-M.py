import requests
import os
import subprocess
import ctypes
import platform
from bs4 import BeautifulSoup
import requests


def Download(url, flags=""):
    # 1. Download the file
    filename = url.split("/")[-1] or "downloaded_file"
    print(f"Downloading {url}...")

    response = requests.get(url)
    with open(filename, 'wb') as f:
        f.write(response.content)

    # Normalize flags to uppercase
    flags = flags.upper()

    # 2. "H" - Hide the file
    if "H" in flags:
        print(f"Hiding {filename}...")
        if platform.system() == "Windows":
            # Sets the hidden attribute on Windows
            ctypes.windll.kernel32.SetFileAttributesW(filename, 2)
        else:
            # On Linux/macOS, renaming with a dot hides it
            os.rename(filename, "." + filename)
            filename = "." + filename

    # 3. "R" - Run the file
    if "R" in flags:
        print(f"Running {filename}...")
        if platform.system() == "Windows":
            os.startfile(filename)
        else:
            # Grant execute permissions and run on Unix
            os.chmod(filename, 0o755)
            subprocess.Popen(["./" + filename])

    return filename

def TextStrip(url, header=None):
    # Default header to look like a standard Chrome browser if none is provided
    if header is None:
        header = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        }

    try:
        print(f"Fetching text from {url}...")
        response = requests.get(url, headers=header)
        response.raise_for_status() # Check if the request was successful

        # Parse the HTML content
        soup = BeautifulSoup(response.text, 'html.parser')

        # Remove script and style elements so their code isn't included in the text
        for script_or_style in soup(["script", "style"]):
            script_or_style.decompose()

        # Get text and clean up extra whitespace
        clean_text = soup.get_text(separator=' ')
        lines = (line.strip() for line in clean_text.splitlines())
        chunks = (phrase.strip() for line in lines for phrase in line.split("  "))
        final_text = '\n'.join(chunk for chunk in chunks if chunk)

        return final_text

    except Exception as e:
        return f"Error: {e}"